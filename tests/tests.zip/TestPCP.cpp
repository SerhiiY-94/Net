#include <catch.hpp>

#include <thread>
#include <chrono>

#include "../NAT_PCP.h"

TEST_CASE("Request read/write", "[PCP]") {
    char buf[128];

    net::PCPNonce nonce;
    net::GenPCPNonce(&nonce, sizeof(net::PCPNonce));

    net::Address client_address(127, 1, 2, 3, 0);
    net::Address external_address(77, 4, 5, 6, 0);
    net::Address remote_address(196, 4, 5, 6, 0);

    {
        net::PCPRequest req;
        req.MakeAnnounceRequest(client_address);

        int sz = req.Write(buf, sizeof(buf));
        REQUIRE(sz != -1);

        net::PCPRequest req1;

        REQUIRE(req1.Read(buf, sz));
        REQUIRE(req1.opcode() == net::OP_ANNOUNCE);
        REQUIRE(req1.lifetime() == 0);
        REQUIRE(req1.client_address().address() == client_address.address());
    }

    {
        net::PCPRequest req;
        req.MakeMapRequest(net::PCP_UDP, 12345, 17891, 7200, client_address, nonce);

        int sz = req.Write(buf, sizeof(buf));
        REQUIRE(sz != -1);

        net::PCPRequest req1;

        REQUIRE(req1.Read(buf, sz));
        REQUIRE(req1.opcode() == net::OP_MAP);
        REQUIRE(req1.internal_port() == 12345);
        REQUIRE(req1.external_port() == 17891);
        REQUIRE(req1.lifetime() == 7200);
        REQUIRE(req1.client_address().address() == client_address.address());
        REQUIRE(req1.nonce() == nonce);
        REQUIRE(req1.proto() == net::PCP_UDP);
        REQUIRE(req1.external_address() == net::Address());
    }

    {
        net::PCPRequest req;
        req.MakePeerRequest(net::PCP_UDP, 12345, 17891, 7200, external_address, 55765, remote_address, nonce);

        int sz = req.Write(buf, sizeof(buf));
        REQUIRE(sz != -1);

        net::PCPRequest req1;

        REQUIRE(req1.Read(buf, sz));
        REQUIRE(req1.opcode() == net::OP_PEER);
        REQUIRE(req1.internal_port() == 12345);
        REQUIRE(req1.external_port() == 17891);
        REQUIRE(req1.lifetime() == 7200);
        REQUIRE(req1.external_address() == external_address);
        REQUIRE(req1.remote_port() == 55765);
        REQUIRE(req1.proto() == net::PCP_UDP);
        REQUIRE(req1.remote_address() == remote_address);
        REQUIRE(req1.nonce() == nonce);
    }
}

TEST_CASE("Response read/write", "[PCP]") {
    char buf[128];

    net::PCPNonce nonce;
    net::GenPCPNonce(&nonce, sizeof(net::PCPNonce));

    net::Address external_address(77, 78, 79, 3, 0), remote_address(111, 12, 14, 3, 0);

    {
        net::PCPResponse resp;
        resp.MakeAnnounceResponse(net::PCP_RES_SUCCESS);

        int sz = resp.Write(buf, sizeof(buf));
        REQUIRE(sz != -1);

        net::PCPResponse resp1;

        REQUIRE(resp1.Read(buf, sz));
        REQUIRE(resp1.opcode() == net::OP_ANNOUNCE);
        REQUIRE(resp1.res_code() == net::PCP_RES_SUCCESS);
        REQUIRE(resp1.lifetime() == 0);
    }

    {
        net::PCPResponse resp;
        resp.MakeMapResponse(net::PCP_UDP, net::PCP_RES_SUCCESS, 12345, 17891, 7200, 120, external_address, nonce);

        int sz = resp.Write(buf, sizeof(buf));
        REQUIRE(sz != -1);

        net::PCPResponse resp1;

        REQUIRE(resp1.Read(buf, sz));
        REQUIRE(resp1.opcode() == net::OP_MAP);
        REQUIRE(resp1.res_code() == net::PCP_RES_SUCCESS);
        REQUIRE(resp1.lifetime() == 7200);
        REQUIRE(resp1.time() == 120);
        REQUIRE(resp1.external_address().address() == external_address.address());
        REQUIRE(resp1.nonce() == nonce);
    }

    {
        net::PCPResponse resp;
        resp.MakePeerResponse(net::PCP_UDP, net::PCP_RES_SUCCESS, 12345, 17891, 7200, 120, external_address, 61478,
                              remote_address, nonce);

        int sz = resp.Write(buf, sizeof(buf));
        REQUIRE(sz != -1);

        net::PCPResponse resp1;

        REQUIRE(resp1.Read(buf, sz));
        REQUIRE(resp1.opcode() == net::OP_PEER);
        REQUIRE(resp1.res_code() == net::PCP_RES_SUCCESS);
        REQUIRE(resp1.lifetime() == 7200);
        REQUIRE(resp1.time() == 120);
        REQUIRE(resp1.external_address().address() == external_address.address());
        REQUIRE(resp1.nonce() == nonce);
    }
}

TEST_CASE("Retransmit", "[PCP]") {
    char buf[128];

    net::UDPSocket fake_pcp_srv;
    fake_pcp_srv.Open(30001);

    net::Address fake_pcp_address(127, 0, 0, 1, 30001);

    net::PCPSession ses(net::PCP_UDP, fake_pcp_address, 30000, 30001, 7200);
    REQUIRE(ses.state() == net::PCPSession::REQUEST_MAPPING);

    ses.Update(16);

    net::Address sender;
    REQUIRE(fake_pcp_srv.Receive(sender, buf, sizeof(buf)));

    ses.Update(16);
    REQUIRE(!fake_pcp_srv.Receive(sender, buf, sizeof(buf)));

    ses.Update(4000);
    REQUIRE(fake_pcp_srv.Receive(sender, buf, sizeof(buf)));

    ses.Update(16);
    REQUIRE(!fake_pcp_srv.Receive(sender, buf, sizeof(buf)));
}

TEST_CASE("R", "[PCP]") {
    char recv_buf[128];
    int size = 0;

    net::UDPSocket pcp_server;
    pcp_server.Open(30001);

    net::Address pcp_server_address(127, 0, 0, 1, 30001);
    net::Address external_address(77, 22, 44, 55, 0);

    net::PCPSession s1(net::PCP_UDP, pcp_server_address, 30000, 30005);

    unsigned int time_acc = 0;

    while (time_acc < 1000 && s1.state() == net::PCPSession::REQUEST_MAPPING) {
        net::Address sender;
        net::PCPRequest req;
        if ((size = pcp_server.Receive(sender, recv_buf, sizeof(recv_buf))) && req.Read(recv_buf, size)) {
            net::PCPResponse resp;
            resp.MakeMapResponse(net::PCP_UDP, net::PCP_RES_SUCCESS, 30000, 30001, 7200, 100, external_address, req.nonce());

            size = resp.Write(recv_buf, sizeof(recv_buf));
            pcp_server.Send(s1.local_addr(), &resp, size);
        }

        s1.Update(16);

        time_acc += 16;
        std::this_thread::sleep_for(std::chrono::milliseconds(16));
    }

    REQUIRE(time_acc < 1000);
    REQUIRE(s1.state() == net::PCPSession::IDLE_MAPPED);
}
