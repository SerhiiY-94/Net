#include <catch.hpp>
#include <iostream>

#include "../Address.h"

TEST_CASE("Address test1", "[Address]") {
	net::Address addr;
	REQUIRE(addr.a() == 0);
	REQUIRE(addr.b() == 0);
	REQUIRE(addr.c() == 0);
	REQUIRE(addr.d() == 0);
	REQUIRE(addr.port() == 0);
	REQUIRE(addr.address() == 0);
}

TEST_CASE("Address test2", "[Address]") {
	const unsigned char a = 100;
	const unsigned char b = 110;
	const unsigned char c = 50;
	const unsigned char d = 12;
	const unsigned short port = 10000;
	net::Address address(a, b, c, d, port);
	REQUIRE(a == address.a());
	REQUIRE(b == address.b());
	REQUIRE(c == address.c());
	REQUIRE(d == address.d());
	REQUIRE(port == address.port());
}

TEST_CASE("Address test3", "[Address]") {
	net::Address x(100, 110, 0, 1, 50000);
	net::Address y(101, 210, 6, 5, 50002);
	REQUIRE(x != y);
	REQUIRE(y == y);
	REQUIRE(x == x);
}

TEST_CASE("Address to string", "[Address]") {
    net::Address x(100, 110, 0, 1, 50000);
    std::string s = x.str();
    REQUIRE(s == "100.110.0.1:50000");
}
