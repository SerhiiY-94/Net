#include <catch.hpp>

#include "../HTTPRequest.h"
#include "../WsConnection.h"

namespace {
    const char pack1[] =
        "GET / HTTP/1.1\r\n"
        "Host: 192.168.0.102:30000\r\n"
        "User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:48.0) Gecko/20100101 Firefox/48.0\r\n"
        "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n"
        "Accept-Language: en-US,en;q=0.5\r\n"
        "Accept-Encoding: gzip, deflate\r\n"
        "Sec-WebSocket-Version: 13\r\n"
        "Origin: null\r\n"
        "Sec-WebSocket-Protocol: binary\r\n"
        "Sec-WebSocket-Extensions: permessage-deflate\r\n"
        //"Sec-WebSocket-Key: rNSWTkPMwVG+y3MD/XMWEA==\r\n"
        "Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\n"
        "Connection: keep-alive, Upgrade\r\n"
        "Pragma: no-cache\r\n"
        "Cache-Control: no-cache\n"
        "Upgrade: websocket\r\n\r\n";

}

TEST_CASE("Parse upgrade to websocket", "[HTTP]") {
    net::HTTPRequest req;
    REQUIRE(req.Parse(pack1));

    REQUIRE(req.method().type == net::GET);
    REQUIRE(req.method().arg == "/");
    REQUIRE(req.method().ver == net::_1_1);

    REQUIRE(req.host_addr() == net::Address(192, 168, 0, 102, 30000));

    REQUIRE(req.field("User-Agent") == "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:48.0) Gecko/20100101 Firefox/48.0");

    REQUIRE(req.field("Accept") == "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
    REQUIRE(req.field("Accept-Language") == "en-US,en;q=0.5");
    REQUIRE(req.field("Accept-Encoding") == "gzip, deflate");

    REQUIRE(req.field("Sec-WebSocket-Version") == "13");
    REQUIRE(req.field("Origin") == "null");
    REQUIRE(req.field("Sec-WebSocket-Protocol") == "binary");
    REQUIRE(req.field("Sec-WebSocket-Extensions") == "permessage-deflate");
    //REQUIRE(req.field("Sec-WebSocket-Key") == "rNSWTkPMwVG+y3MD/XMWEA==");

    REQUIRE(req.field("Connection") == "keep-alive, Upgrade");
    REQUIRE(req.field("Pragma") == "no-cache");
    REQUIRE(req.field("Cache-Control") == "no-cache");
    REQUIRE(req.field("Upgrade") == "websocket");
}