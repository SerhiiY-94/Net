#include <catch.hpp>

#include <net/Var.h>
#include <net/VarContainer.h>

TEST_CASE("Var test1", "[Var]") {
	net::Var<int> v1 = { "V1" };
	net::Var<int> v2 = { "V2" };

	v1 = 12;
	v2 = 12;

	REQUIRE(v1 == v2);
	REQUIRE(v2.val() == 12);
	REQUIRE(v1.hash() != v2.hash());
}

TEST_CASE("Var test2", "[Var]") {
	net::Var<int> v1 = { "VAR" };
	net::Var<int> v2 = { "VAR" };

	v1 = 13;
	v2 = 12;

	REQUIRE(v1 != v2);
	REQUIRE(v1.hash() == v2.hash());
}

TEST_CASE("Var test3", "[Var]") {
	struct S1 {
		int a, b, c;
		float f;
	};

	struct S2 {
		float f1, f2;
		double dd;
	};

	net::Var<S1> v1 = { "VAR" };
	net::Var<S2> v2 = { "VAR" };

	v1 = {1, 2, 3, 5.13f};
	v2 = {11.1f, 12.2f, 10.0};

	REQUIRE(v1.a == 1);
	REQUIRE(v2.dd == 10.0);
}

TEST_CASE("VarContainer save/load test", "[VarContainer]") {
	using namespace net; // for le_uint32

	struct S1 { float x; short s; double d; };
	std::vector<unsigned char> pack;
	net::Var<int> v1 = { "V1", 12 };
	net::Var<int> v2 = { "V2", 13 };
	net::Var<float> v3 = { "V3", 25.251f };
	net::Var<S1> v4 = { "V4" };
	v4 = { 4.5f, 11, 5.6 };

	{
		net::VarContainer cnt;

		cnt.SaveVar(v1);
		cnt.SaveVar(v2);
		cnt.SaveVar(v3);
		cnt.SaveVar(v4);

		REQUIRE(cnt.size() == 4);
		pack = cnt.Pack();
		REQUIRE(pack.size() == sizeof(le_uint32) * 2 + 2 * 4 * sizeof(le_uint32) + 2 * sizeof(int) + sizeof(float) + sizeof(S1));
	}

	v1 = 11;
	v2 = 14;
	v3 = 15.044f;
	v4 = { -4.5f, -11, -5.6 };
	REQUIRE(v1 == 11);
	REQUIRE(v2 == 14);
	REQUIRE(v3 == 15.044f);
	REQUIRE(v4.d == -5.6);

	net::VarContainer cnt;
	cnt.UnPack(pack);
	REQUIRE(cnt.size() == 4);

	REQUIRE(cnt.LoadVar(v1));
	REQUIRE(cnt.LoadVar(v2));
	REQUIRE(cnt.LoadVar(v3));
	REQUIRE(cnt.LoadVar(v4));

	REQUIRE(v1 == 12);
	REQUIRE(v2 == 13);
	REQUIRE(v3 == 25.251f);
	REQUIRE(v4.d == 5.6);
}

TEST_CASE("VarContainer update test", "[VarContainer]") {
	std::vector<unsigned char> pack;
	net::Var<int> v1 = { "V1", 12 };
	net::Var<int> v2 = { "V2", 13 };
	net::Var<float> v3 = { "V3", 25.251f };
	{
		net::VarContainer cnt;

		cnt.SaveVar(v1);
		cnt.SaveVar(v2);
		cnt.SaveVar(v3);

		v1 = 110;
		v2 = 140;
		v3 = 150.044f;

		cnt.UpdateVar(v1);
		cnt.UpdateVar(v2);
		cnt.UpdateVar(v3);

        v1 = 11;
        v2 = 14;
        v3 = 15.044f;

        cnt.UpdateVar(v1);
        cnt.UpdateVar(v2);
        cnt.UpdateVar(v3);

		pack = cnt.Pack();
	}
	net::VarContainer cnt;
	cnt.UnPack(pack);
	REQUIRE(cnt.size() == 3);

	REQUIRE(cnt.LoadVar(v1));
	REQUIRE(cnt.LoadVar(v2));
	REQUIRE(cnt.LoadVar(v3));

	REQUIRE(v1 == 11);
	REQUIRE(v2 == 14);
	REQUIRE(v3 == 15.044f);
}

TEST_CASE("VarContainer nested test", "[VarContainer]") {
	net::VarContainer cnt;
	net::Var<net::VarContainer> c1("CONT1"), c2("CONT2");
	struct S1 { float x; short s; double d; };
	net::Var<int> v1 = { "V1", 12 };
	net::Var<int> v2 = { "V2", 14 };
	net::Var<float> v3 = { "V3", 25.251f };
	net::Var<S1> v4 = { "V4" };
	v4 = { 4.5f, 11, 5.6 };
	
	c1.SaveVar(v1);
	c1.SaveVar(v2);
	c2.SaveVar(v3);
	c2.SaveVar(v4);

	cnt.SaveVar(c1);
	cnt.SaveVar(c2);

	net::Packet packet = cnt.Pack();

	REQUIRE(c1.size() == 2);
	REQUIRE(c2.size() == 2);
	REQUIRE(cnt.size() == 2);

	v1 = 123;
	v2 = 557575;
	v3 = 32.058f;
	v4 = {0.25f, 45, 7.56};

	c1.clear();
	c2.clear();
	cnt.clear();

	cnt.UnPack(packet);

	REQUIRE(cnt.LoadVar(c1));
	REQUIRE(cnt.LoadVar(c2));

	REQUIRE(c1.LoadVar(v1));
	REQUIRE(c1.LoadVar(v2));

	REQUIRE(c2.LoadVar(v3));
	REQUIRE(c2.LoadVar(v4));
	
	REQUIRE(c1.size() == 2);
	REQUIRE(c2.size() == 2);
	REQUIRE(cnt.size() == 2);

	REQUIRE(v1.val() == 12);
	REQUIRE(v2.val() == 14);
	REQUIRE(v3 == 25.251f);
	REQUIRE(v4.x == 4.5f);
	REQUIRE(v4.s == 11);
	REQUIRE(v4.d == 5.6);
}

TEST_CASE("VarContainer large struct", "[VarContainer]") {
	struct SomeLargeGameState {
        char data[5000];
        int number;
    };
    SomeLargeGameState state;
    state.number = 178;

    net::VarContainer cnt;
    net::Var<SomeLargeGameState> s1 = { "Variable", state };
    REQUIRE(s1.number == state.number);
    cnt.SaveVar(s1);

    net::Var<SomeLargeGameState> s2 = { "Variable", state };
    cnt.LoadVar(s2);
    REQUIRE(s2.number == state.number);
}