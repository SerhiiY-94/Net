#include <catch.hpp>
#include <cstring>

#include "../Socket.h"

TEST_CASE("UDPSocket open/close", "[UDPSocket]") {
	net::UDPSocket socket;
	REQUIRE(!socket.IsOpen());
	REQUIRE_NOTHROW(socket.Open(30000));
	REQUIRE(socket.IsOpen());
	socket.Close();
	REQUIRE(!socket.IsOpen());
	REQUIRE_NOTHROW(socket.Open(30000));
	REQUIRE(socket.IsOpen());
}

TEST_CASE("UDPSocket same port fail", "[UDPSocket]") {
	net::UDPSocket a, b;
	REQUIRE_NOTHROW(a.Open(30000, false));
	REQUIRE_THROWS(b.Open(30000, false));
	REQUIRE(a.IsOpen());
	REQUIRE(!b.IsOpen());
}

TEST_CASE("UDPSocket send and receive packets", "[UDPSocket]") {
	net::UDPSocket a, b;
	REQUIRE_NOTHROW(a.Open(30000));
	REQUIRE_NOTHROW(b.Open(30001));
	const char packet[] = "packet data";
	bool a_received_packet = false;
	bool b_received_packet = false;
	while (!a_received_packet && !b_received_packet) {
		REQUIRE(a.Send(net::Address(127, 0, 0, 1, 30001), packet, sizeof(packet)));
		REQUIRE(b.Send(net::Address(127, 0, 0, 1, 30000), packet, sizeof(packet)));

		while (true) {
			net::Address sender;
			char buffer[256];
			int bytes_read = a.Receive(sender, buffer, sizeof(buffer));
			if (bytes_read == 0) {
				break;
			}
			if (bytes_read == sizeof(packet) && strcmp(buffer, packet) == 0) {
				a_received_packet = true;
			}
		}

		while (true) {
			net::Address sender;
			char buffer[256];
			int bytes_read = b.Receive(sender, buffer, sizeof(buffer));
			if (bytes_read == 0) {
				break;
			}
			if (bytes_read == sizeof(packet) && strcmp(buffer, packet) == 0) {
				b_received_packet = true;
			}
		}
	}
	REQUIRE(a_received_packet);
    REQUIRE(b_received_packet);
}