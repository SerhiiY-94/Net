#include <catch.hpp>

#include <cstring>

#include "../BitMsg.h"

class TestMsg : public net::BitMsg {
    uint8_t buf[256];
public:
    TestMsg() : BitMsg(buf, sizeof(buf)) {
        memset(buf, 0, sizeof(buf));
    }
};
#if !defined(_MSC_VER)
TEST_CASE_METHOD(TestMsg, "Writing bits", "[BitMsg]") {
    SECTION("Wrong bits write number should throw runtime_error") {
        REQUIRE_THROWS(WriteBits(0, 0));
        REQUIRE_THROWS(WriteBits(0, -32));
        REQUIRE_THROWS(WriteBits(0, 33));
        // Overflow check
        REQUIRE_THROWS(WriteBits(16, 3));
        REQUIRE_NOTHROW(WriteBits(7, 3));
        REQUIRE_THROWS(WriteBits(-7, 3));
        REQUIRE_THROWS(WriteBits(4, -3));
        REQUIRE_NOTHROW(WriteBits(3, -3));
        REQUIRE_THROWS(WriteBits(-10, -3));
        REQUIRE_NOTHROW(WriteBits(-4, -3));
    }
    SECTION("Write values") {
        REQUIRE(len_ == 0);
        WriteBits(1, 1);
        REQUIRE(write_data_[0] == 0b1);
        REQUIRE(len_ == 0);
        WriteBits(4, 3);
        REQUIRE(write_data_[0] == 0b1001);
        REQUIRE(len_ == 0);
        WriteBits(2, 2);
        REQUIRE(write_data_[0] == 0b101001);
        REQUIRE(len_ == 0);
        WriteBits(3, 2);
        REQUIRE(write_data_[0] == 0b11101001);
        REQUIRE(len_ == 1);
        WriteBits(1, 1);
        REQUIRE(write_data_[0] == 0b11101001);
        REQUIRE(write_data_[1] == 0b1);
        REQUIRE(len_ == 1);
        WriteBits(12, 4);
        REQUIRE(write_data_[0] == 0b11101001);
        REQUIRE(write_data_[1] == 0b11001);
        REQUIRE(len_ == 1);
    }
}

TEST_CASE_METHOD(TestMsg, "Reading bits", "[BitMsg]") {
    SECTION("Wrong bits read number should throw runtime_error") {
        REQUIRE_THROWS(ReadBits(0));
        REQUIRE_THROWS(ReadBits(-32));
        REQUIRE_THROWS(ReadBits(33));
    }

    SECTION("Read values") {
        len_ = 2;
        write_data_[0] = 0b11101001;
        write_data_[1] = 0b11001;
        REQUIRE(ReadBits(1) == 1);
        REQUIRE(ReadBits(3) == 4);
        REQUIRE(ReadBits(2) == 2);
        REQUIRE(ReadBits(2) == 3);
        REQUIRE(ReadBits(1) == 1);
        REQUIRE(ReadBits(4) == 12);
    }
}

TEST_CASE_METHOD(TestMsg, "Writing values", "[BitMsg]") {
    bool b = true;
    char c1 = -123;
    uint8_t c2 = 253;
    short s1 = -12345;
    unsigned short s2 = 29103;
    int i1 = -891355;
    unsigned i2 = 6565558;
    int64_t ll1 = 656555812345558;
    int temp = 121213345;
    float f1 = *reinterpret_cast<float*>(&temp);
    Write(b);
    REQUIRE(write_data_[0] == 0b1);
    Write<int8_t>(c1);
    REQUIRE(write_data_[0] == 0b00001011);
    REQUIRE(write_data_[1] == 0b1);
    Write(c2);
    REQUIRE(write_data_[0] == 0b00001011);
    REQUIRE(write_data_[1] == 0b11111011);
    REQUIRE(write_data_[2] == 0b1);
    Write(s1);
    REQUIRE(write_data_[0] == 0b00001011);
    REQUIRE(write_data_[1] == 0b11111011);
    REQUIRE(write_data_[2] == 0b10001111);
    REQUIRE(write_data_[3] == 0b10011111);
    REQUIRE(write_data_[4] == 0b1);
    Write(s2);
    REQUIRE(write_data_[0] == 0b00001011);
    REQUIRE(write_data_[1] == 0b11111011);
    REQUIRE(write_data_[2] == 0b10001111);
    REQUIRE(write_data_[3] == 0b10011111);
    REQUIRE(write_data_[4] == 0b01011111);
    REQUIRE(write_data_[5] == 0b11100011);
    REQUIRE(write_data_[6] == 0b0);
    Write<int32_t>(i1);
    REQUIRE(write_data_[0] == 0b00001011);
    REQUIRE(write_data_[1] == 0b11111011);
    REQUIRE(write_data_[2] == 0b10001111);
    REQUIRE(write_data_[3] == 0b10011111);
    REQUIRE(write_data_[4] == 0b01011111);
    REQUIRE(write_data_[5] == 0b11100011);
    REQUIRE(write_data_[6] == 0b01001010);
    REQUIRE(write_data_[7] == 0b11001100);
    REQUIRE(write_data_[8] == 0b11100100);
    REQUIRE(write_data_[9] == 0b11111111);
    REQUIRE(write_data_[10] == 0b1);
    Write<uint32_t>(i2);
    REQUIRE(write_data_[0] == 0b00001011);
    REQUIRE(write_data_[1] == 0b11111011);
    REQUIRE(write_data_[2] == 0b10001111);
    REQUIRE(write_data_[3] == 0b10011111);
    REQUIRE(write_data_[4] == 0b01011111);
    REQUIRE(write_data_[5] == 0b11100011);
    REQUIRE(write_data_[6] == 0b01001010);
    REQUIRE(write_data_[7] == 0b11001100);
    REQUIRE(write_data_[8] == 0b11100100);
    REQUIRE(write_data_[9] == 0b11111111);
    REQUIRE(write_data_[10] == 0b01101101);
    REQUIRE(write_data_[11] == 0b01011101);
    REQUIRE(write_data_[12] == 0b11001000);
    REQUIRE(write_data_[13] == 0b00000000);
    REQUIRE(write_data_[14] == 0b0);
    Write<int64_t>(ll1);
    REQUIRE(write_data_[0] == 0b00001011);
    REQUIRE(write_data_[1] == 0b11111011);
    REQUIRE(write_data_[2] == 0b10001111);
    REQUIRE(write_data_[3] == 0b10011111);
    REQUIRE(write_data_[4] == 0b01011111);
    REQUIRE(write_data_[5] == 0b11100011);
    REQUIRE(write_data_[6] == 0b01001010);
    REQUIRE(write_data_[7] == 0b11001100);
    REQUIRE(write_data_[8] == 0b11100100);
    REQUIRE(write_data_[9] == 0b11111111);
    REQUIRE(write_data_[10] == 0b01101101);
    REQUIRE(write_data_[11] == 0b01011101);
    REQUIRE(write_data_[12] == 0b11001000);
    REQUIRE(write_data_[13] == 0b00000000);
    REQUIRE(write_data_[14] == 0b10101100);
    REQUIRE(write_data_[15] == 0b10101101);
    REQUIRE(write_data_[16] == 0b11110000);
    REQUIRE(write_data_[17] == 0b10011111);
    REQUIRE(write_data_[18] == 0b01000100);
    REQUIRE(write_data_[19] == 0b10101010);
    REQUIRE(write_data_[20] == 0b00000100);
    REQUIRE(write_data_[21] == 0b00000000);
    REQUIRE(write_data_[22] == 0b0);
    Write<float>(f1);
    REQUIRE(write_data_[0] == 0b00001011);
    REQUIRE(write_data_[1] == 0b11111011);
    REQUIRE(write_data_[2] == 0b10001111);
    REQUIRE(write_data_[3] == 0b10011111);
    REQUIRE(write_data_[4] == 0b01011111);
    REQUIRE(write_data_[5] == 0b11100011);
    REQUIRE(write_data_[6] == 0b01001010);
    REQUIRE(write_data_[7] == 0b11001100);
    REQUIRE(write_data_[8] == 0b11100100);
    REQUIRE(write_data_[9] == 0b11111111);
    REQUIRE(write_data_[10] == 0b01101101);
    REQUIRE(write_data_[11] == 0b01011101);
    REQUIRE(write_data_[12] == 0b11001000);
    REQUIRE(write_data_[13] == 0b00000000);
    REQUIRE(write_data_[14] == 0b10101100);
    REQUIRE(write_data_[15] == 0b10101101);
    REQUIRE(write_data_[16] == 0b11110000);
    REQUIRE(write_data_[17] == 0b10011111);
    REQUIRE(write_data_[18] == 0b01000100);
    REQUIRE(write_data_[19] == 0b10101010);
    REQUIRE(write_data_[20] == 0b00000100);
    REQUIRE(write_data_[21] == 0b00000000);
    REQUIRE(write_data_[22] == 0b01000010);
    REQUIRE(write_data_[23] == 0b00100011);
    REQUIRE(write_data_[24] == 0b01110011);
    REQUIRE(write_data_[25] == 0b00001110);
    REQUIRE(write_data_[26] == 0b0);
}

TEST_CASE_METHOD(TestMsg, "Reading values", "[BitMsg]") {
    len_ = 27;
    write_data_[0] = 0b00001011;
    write_data_[1] = 0b11111011;
    write_data_[2] = 0b10001111;
    write_data_[3] = 0b10011111;
    write_data_[4] = 0b01011111;
    write_data_[5] = 0b11100011;
    write_data_[6] = 0b01001010;
    write_data_[7] = 0b11001100;
    write_data_[8] = 0b11100100;
    write_data_[9] = 0b11111111;
    write_data_[10] = 0b01101101;
    write_data_[11] = 0b01011101;
    write_data_[12] = 0b11001000;
    write_data_[13] = 0b00000000;
    write_data_[14] = 0b10101100;
    write_data_[15] = 0b10101101;
    write_data_[16] = 0b11110000;
    write_data_[17] = 0b10011111;
    write_data_[18] = 0b01000100;
    write_data_[19] = 0b10101010;
    write_data_[20] = 0b00000100;
    write_data_[21] = 0b00000000;
    write_data_[22] = 0b01000010;
    write_data_[23] = 0b00100011;
    write_data_[24] = 0b01110011;
    write_data_[25] = 0b00001110;
    write_data_[26] = 0b0;
    REQUIRE(Read<bool>());
    REQUIRE(Read<int8_t>() == -123);
    REQUIRE(Read<uint8_t>() == 253);
    REQUIRE(Read<int16_t>() == -12345);
    REQUIRE(Read<uint16_t>() == 29103);
    REQUIRE(Read<int32_t>() == -891355);
    REQUIRE(Read<uint32_t>() == 6565558);
    REQUIRE(Read<int64_t>() == 656555812345558);
    int temp = 121213345;
    float f1 = *reinterpret_cast<float*>(&temp);
    REQUIRE(Read<float>() == f1);
}
#endif
