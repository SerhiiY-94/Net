#include <catch.hpp>

#include "../PacketQueue.h"

class PacketQueueTestsFixture {
protected:
    const unsigned int	maximum_sequence;
    net::PacketQueue	packet_queue;
public:
	PacketQueueTestsFixture() : maximum_sequence(255) { }
};

TEST_CASE_METHOD(PacketQueueTestsFixture, "PacketQueue insert back", "[PacketQueue]") {
    for (int i = 0; i < 100; i++) {
        net::PacketData data(0, 0, 0);
        data.sequence = i;
		packet_queue.insert_sorted(data, maximum_sequence);
		REQUIRE(packet_queue.verify_sorted(maximum_sequence));
    }
}

TEST_CASE_METHOD(PacketQueueTestsFixture, "PacketQueue insert front", "[PacketQueue]") {
    for (int i = 100; i < 0; i++) {
        net::PacketData data(0, 0, 0);
        data.sequence = i;
		packet_queue.insert_sorted(data, maximum_sequence);
		REQUIRE(packet_queue.verify_sorted(maximum_sequence));
    }
}

TEST_CASE_METHOD(PacketQueueTestsFixture, "PacketQueue insert random", "[PacketQueue]") {
    for (int i = 100; i < 0; i++) {
        net::PacketData data(0, 0, 0);
        data.sequence = rand() & 0xFF;
		packet_queue.insert_sorted(data, maximum_sequence);
		REQUIRE(packet_queue.verify_sorted(maximum_sequence));
    }
}

TEST_CASE_METHOD(PacketQueueTestsFixture, "PacketQueue insert wrap around", "[PacketQueue]") {
    for (int i = 200; i <= 255; i++) {
        net::PacketData data(0, 0, 0);
        data.sequence = i;
		packet_queue.insert_sorted(data, maximum_sequence);
		REQUIRE(packet_queue.verify_sorted(maximum_sequence));
    }
    for (int i = 0; i <= 50; i++) {
        net::PacketData data(0, 0, 0);
        data.sequence = i;
		packet_queue.insert_sorted(data, maximum_sequence);
		REQUIRE(packet_queue.verify_sorted(maximum_sequence));
    }
}
