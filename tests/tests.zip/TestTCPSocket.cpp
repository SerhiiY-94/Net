#include <catch.hpp>
#include <cstring>
#include <thread>

#include "../Socket.h"

TEST_CASE("TCPSocket open/close", "[TCPSocket]") {
	net::TCPSocket socket;
	REQUIRE(!socket.IsOpen());
	REQUIRE_NOTHROW(socket.Open(30000));
	REQUIRE(socket.IsOpen());
	socket.Close();
	REQUIRE(!socket.IsOpen());
	REQUIRE_NOTHROW(socket.Open(30000));
	REQUIRE(socket.IsOpen());
}

TEST_CASE("TCPSocket same port fail", "[TCPSocket]") {
	net::TCPSocket a, b;
	REQUIRE_NOTHROW(a.Open(30000, false));
	REQUIRE_THROWS(b.Open(30000, false));
	REQUIRE(a.IsOpen());
	REQUIRE(!b.IsOpen());
}

TEST_CASE("TCPSocket send and receive packets", "[TCPSocket]") {
	net::TCPSocket a, b;
	REQUIRE_NOTHROW(a.Open(30000));
	REQUIRE_NOTHROW(b.Open(30001));
	const char packet[] = "packet data";
	bool a_received_packet = false;
	bool b_received_packet = false;
	REQUIRE(b.Listen());
    //std::thread thr([&]() {
        //REQUIRE(a.Connect(net::Address(127, 0, 0, 1, 30001)));
        //REQUIRE(a.Send(packet, sizeof(packet)));
    //});
    std::thread thr([&]() {
        while (true) {
            if (b.Accept()) {
                char buffer[256];
                int bytes_read = b.Receive(buffer, sizeof(buffer));
                if (bytes_read) {
                    REQUIRE(bytes_read == sizeof(packet));
                    REQUIRE(b.Send(packet, sizeof(packet)));
                    bytes_read = a.Receive(buffer, sizeof(buffer));
                    REQUIRE(bytes_read == sizeof(packet));
                    break;
                }
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    });
    REQUIRE(a.Connect(net::Address(127, 0, 0, 1, 30001)));
    REQUIRE(a.Send(packet, sizeof(packet)));
    thr.join();
}