#include <catch.hpp>

#include "../Compress.h"

TEST_CASE("LZO Compress", "[Compress]") {
	net::Packet test_buf(1024);
	for (int i = 0; i < 256; i++) {
		test_buf[i] = i % 255;
	}

	for (int i = 256; i < 768; i++) {
		test_buf[i] = 0;
	}

	for (int i = 768; i < test_buf.size(); i++) {
		test_buf[i] = i % 255;
	}
	
	net::Packet compr = net::CompressLZO(test_buf);

	printf("size before %i, size after %i\n", int(test_buf.size()), int(compr.size()));

	net::Packet decompr = net::DecompressLZO(compr);

	REQUIRE(decompr.size() == test_buf.size());
	REQUIRE(test_buf == decompr);
}